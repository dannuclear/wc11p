
ALTER TABLE TUser
ADD employee_id  varchar(40)  NULL
go


